package Ignore;

import java.util.Date;

import org.apache.mina.util.ExpiringMap;



public class Test {
	
	private static final int timeToLive = 5;
	private static final int intervalCheck = 6;

	private ExpiringMap<String, Date> userChallengeMap = new ExpiringMap<>(timeToLive, intervalCheck);
	
	private Runnable r = new Runnable() {
		@SuppressWarnings("static-access")
		public void run() {
		   while(true) {
			   for(String str : userChallengeMap.keySet()) {
				   System.out.println(str +  " : " + userChallengeMap);
				  
			   }
			   System.out.println("====================================================");
			   try {
				Thread.currentThread().sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
		}
	};
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws Exception{
		
		Test t = new Test();
		t.startExpirer();
		
		t.startMapMonitor();
		
		t.stuffMap("shadab");
		
		Thread.currentThread().sleep(1000);
				
		t.stuffMap("yasmeen");
		
		Thread.currentThread().sleep(1000);
		
		t.stuffMap("hamzah");
		
		Thread.currentThread().sleep(1000);		
		
	}
	
	public void startExpirer() {
		userChallengeMap.getExpirer().startExpiring();
	}
	
	public void startMapMonitor() {
		Thread t = new Thread(r);
		t.start();
	}
	
	public void stuffMap (String str) {
		userChallengeMap.put(str, new Date());		
	}
	
	
	
}
