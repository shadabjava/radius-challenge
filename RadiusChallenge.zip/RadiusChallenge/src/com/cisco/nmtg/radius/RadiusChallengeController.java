package com.cisco.nmtg.radius;

import java.util.List;
import javax.servlet.http.HttpSession;
import org.jasig.cas.adaptors.radius.JRadiusServerImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import net.jradius.packet.attribute.AttributeFactory;
import net.jradius.packet.attribute.RadiusAttribute;
import org.jasig.cas.adaptors.radius.RadiusResponse;

@Controller
public class RadiusChallengeController {

	private JRadiusServerImpl radiusServer;	

	public JRadiusServerImpl getRadiusServer() {
		return radiusServer;
	}
	
	@Autowired
	public void setRadiusServer(JRadiusServerImpl radiusServer) {
		this.radiusServer = radiusServer;
	}

	@RequestMapping("/")
	public String showLogin() {
		return "login";
	}
			
	@RequestMapping("/radiusRequest")
	public ModelAndView invokeRSA(HttpSession session, Credentials credentials) {
		String username = credentials.getUsername();
		//if it's a request after the access-challenge with a user then username may not be available, so we need to pull it out
		// of the session
		if(username == null || username.equals("")) {
			username = session.getAttribute("username").toString();
		}
		RadiusResponse radiusResponse = radiusServer.authenticate(username, credentials.getPassword());
		
		ModelAndView mv = new ModelAndView();
		String resp = null;
		switch(radiusResponse.getCode()) {
		case 2:
			resp = "Access Accept";
			mv.setViewName("accept");
			mv.addObject("RadiusResponse", resp);
			break;
		case 11:
			// if it's a dialogue with user, then to make it stateful we need to store the username in the session
			session.setAttribute("username", username);
			List<RadiusAttribute> attributes = radiusResponse.getAttributes();
			for(RadiusAttribute attrib : attributes) {
				if(attrib.getAttributeName().equalsIgnoreCase("Reply-Message")) { 
						resp = attrib.getValue() + "";
						break;
				}
			}
			mv.setViewName("challengeInput");			
			mv.addObject("RadiusResponse", resp);
			break;
		case 3:
			resp = "Access Reject";
			mv.setViewName("reject");
			mv.addObject("RadiusResponse", resp);
			break;
		default:
			break;		
		} 
		return mv;
	}


	static {
		AttributeFactory.loadAttributeDictionary("net.jradius.dictionary.AttributeDictionaryImpl");
	}
	
	/*public static AttributeList getAttributeList(String username, String password, String challenge) {
		final AttributeList attributeList = new AttributeList();
		attributeList.add(new Attr_UserName(username));
		if (password != null && password != "")
			attributeList.add(new Attr_UserPassword(password));
		if (challenge != null && challenge != "") {
			attributeList.add(new Attr_ChallengeState(challenge));
			attributeList.add(new Attr_UserPassword(challenge));
		}
		return attributeList;
	}*/
}
