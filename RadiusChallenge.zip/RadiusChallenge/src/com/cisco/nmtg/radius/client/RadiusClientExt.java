package com.cisco.nmtg.radius.client;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.security.NoSuchAlgorithmException;
import org.apache.mina.util.ExpiringMap;
import net.jradius.client.RadiusClient;
import net.jradius.client.RadiusClientTransport;
import net.jradius.client.auth.PAPAuthenticator;
import net.jradius.client.auth.RadiusAuthenticator;
import net.jradius.dictionary.Attr_Password;
import net.jradius.dictionary.Attr_UserName;
import net.jradius.exception.RadiusException;
import net.jradius.exception.UnknownAttributeException;
import net.jradius.packet.AccessChallenge;
import net.jradius.packet.AccessRequest;
import net.jradius.packet.RadiusPacket;
import net.jradius.packet.RadiusResponse;
import net.jradius.packet.attribute.AttributeDictionary;
import net.jradius.packet.attribute.AttributeFactory;
import net.jradius.packet.attribute.RadiusAttribute;
import net.jradius.util.RadiusUtils;

/**
 * 
 * @author shadabkh enhanced radius-client for Access Challenge support via
 *         dialogue with User
 *
 */

public class RadiusClientExt extends RadiusClient {

	/*
	 * time in seconds; can be made configurable from conf file instead of hard coding. 
	 * An AccessChallenge like Next-Token-Mode takes a maximum of 2 tokencodes. Each tokencode/passcode expires in 60 sec.
	 */
	private static final int timeToLive = 120;
	private static final int intervalCheck = 130;

	/*
	 * Self purging map which removes expired entries every intervalCheck. It
	 * stores entry with key as username and value as lastAccessChallenge for
	 * that user. In case of disconnect/timeout with Radius Server, the hanging
	 * <username,challenge> will expire and get removed by the expiring map *
	 */
	private static final ExpiringMap<String, AccessChallenge> userChallengeMap = new ExpiringMap<>(timeToLive,
			intervalCheck);

	public RadiusClientExt() throws IOException {
		super();
	}

	public RadiusClientExt(DatagramSocket socket, InetAddress address, String secret, int authPort, int acctPort,
			int timeout) throws SocketException {
		super(socket, address, secret, authPort, acctPort, timeout);
	}

	public RadiusClientExt(DatagramSocket socket, InetAddress address, String secret) {
		super(socket, address, secret);
	}

	public RadiusClientExt(DatagramSocket socket) {
		super(socket);
	}

	public RadiusClientExt(String address, String secret, int authPort, int acctPort, int timeout) throws IOException {
		super(InetAddress.getByName(address), secret, authPort, acctPort, timeout);
	}

	public RadiusClientExt(InetAddress address, String secret, int authPort, int acctPort, int timeout)
			throws IOException {
		super(address, secret, authPort, acctPort, timeout);
	}

	public RadiusClientExt(InetAddress address, String secret) throws IOException {
		super(address, secret);
	}

	public RadiusClientExt(RadiusClientTransport transport) {
		super(transport);
	}

	@Override
	public RadiusResponse authenticate(AccessRequest p, RadiusAuthenticator auth, int retries)
			throws RadiusException, UnknownAttributeException, NoSuchAlgorithmException {

		// trigger the worker thread in ExpiringMap
		userChallengeMap.getExpirer().startExpiring();

		if (auth == null)
			auth = new PAPAuthenticator();

		auth.setupRequest(this, p);
		auth.processRequest(p);
		String username = p.getAttributes().get(Attr_UserName.NAME).getValue() + "";
		while (true) {
			RadiusResponse reply = null;
			if (!userChallengeMap.containsKey(username)) {
				// First AccessRequest
				reply = transport.sendReceive(p, retries);
				if (reply instanceof AccessChallenge) {
					userChallengeMap.put(username, (AccessChallenge) reply);
				}
				return reply;
			} else {
				// AccessRequest post AccessChallenge
				byte[] sharedSecret = p.getAttributes().get(Attr_Password.NAME).getValue().getBytes();
				constructAccessRequest(p, sharedSecret);
				AccessChallenge lastAccessChallenge = userChallengeMap.get(username);
				processChallenge(p, lastAccessChallenge);
				try {
					reply = transport.sendReceive(p, retries);
				} catch (RadiusException ex) {
					ex.printStackTrace();
				} finally {
					if (reply instanceof AccessChallenge) {
						// if further challenge update the map with latest response
						userChallengeMap.put(username, (AccessChallenge) reply);
					} else {
						// if it's AccessAccept or AccessReject or anything other than AccessChallenge, lets remove the entry
						userChallengeMap.remove(username);
					}
				}
				return reply;
			}
		}
	}

	public void processChallenge(RadiusPacket p, RadiusPacket c) {
		RadiusAttribute stateAttribute = c.findAttribute(AttributeDictionary.STATE);
		if (stateAttribute != null) {
			p.overwriteAttribute(stateAttribute);
		}
	}

	/**
	 * @author shadabkh
	 * @param p
	 * @param secret
	 * @throws UnknownAttributeException
	 */

	public void constructAccessRequest(AccessRequest p, byte[] secret) throws UnknownAttributeException {
		RadiusAttribute a = p.findAttribute(AttributeDictionary.USER_PASSWORD);
		if (a != null) {
			p.removeAttribute(a);
		}
		RadiusAttribute attr = AttributeFactory.newAttribute("User-Password");
		attr.setValue(secret);
		p.addAttribute(attr);
	}

	/**
	 * @author shadabkh
	 * @param p
	 * @param value
	 * @throws UnknownAttributeException
	 */

	public void constructAccessRequest(AccessRequest p, String value) throws UnknownAttributeException {
		RadiusAttribute a = p.findAttribute(AttributeDictionary.USER_PASSWORD);
		if (a != null) {
			p.removeAttribute(a);
		}
		RadiusAttribute attr = AttributeFactory.newAttribute("User-Password");
		attr.setValue(RadiusUtils.encodePapPassword(value.getBytes(),
				p.createAuthenticator(null, 0, 0, this.getSharedSecret()), this.getSharedSecret()));
		p.addAttribute(attr);
	}

	/*	*//**
			 * @author shadabkh
			 * @param challenge
			 * @return
			 * @throws UnknownAttributeException
			 * 
			 *//*
			 * 
			 * public String parsePin(RadiusResponse challenge) throws
			 * UnknownAttributeException { String pinGarbled =
			 * challenge.getAttributeValue("Reply-Message").toString(); String
			 * arr[] = pinGarbled.split(":"); String subArr[] =
			 * arr[1].split(","); String pin = subArr[0].trim();
			 * System.out.println(pin); return pin; }
			 */
}
